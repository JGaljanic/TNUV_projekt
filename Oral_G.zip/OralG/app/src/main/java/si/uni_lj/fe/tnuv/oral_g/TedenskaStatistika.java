package si.uni_lj.fe.tnuv.oral_g;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TedenskaStatistika extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tedenska_statistika);
    }
}