package si.uni_lj.fe.tnuv.oral_g;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Statistika extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistika);
    }

    public void odpriZobozdravniski(View ZobozdravniskiPregled) {
        Intent z = new Intent(this, ZobozdravniskiPregled.class);
        startActivity(z);
    }

    public void odpriTedensko(View TedenskaStatistika) {
        Intent t = new Intent(this, TedenskaStatistika.class);
        startActivity(t);
    }

    public void odpriZivljenska(View ZivljenjskaStatistika) {
        Intent s = new Intent(this, ZivljenjskaStatistika.class);
        startActivity(s);
    }

}
